# -*- coding: utf-8 -*-
"""Modern Zapret GUI with portable .zapret domain lists."""
import os, sys, json, zipfile, shutil, subprocess, threading, urllib.request, tempfile
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

ROOT = Path(__file__).resolve().parent
LISTS_DIR = ROOT / "custom_lists"
BG, PANEL, PANEL2, FG, MUTED = "#0b1020", "#131b2e", "#1b2740", "#eef3ff", "#9baac4"
ACCENT, GREEN, RED = "#168bd2", "#28b985", "#d95567"
IPSET_URL = "https://raw.githubusercontent.com/Flowseal/zapret-discord-youtube/refs/heads/main/.service/ipset-service.txt"

class App:
    def __init__(self, root):
        self.root = root
        root.title("Zapret Control Center")
        root.geometry("1000x720")
        root.minsize(850, 620)
        root.configure(bg=BG)
        self.lists = {}
        self.active = tk.StringVar()
        self.status = tk.StringVar(value="Готово")
        self.strategy = tk.StringVar()
        self._style()
        self._splash()

    def _style(self):
        s = ttk.Style()
        s.theme_use("clam")
        s.configure("TCombobox", fieldbackground=PANEL2, background=PANEL2, foreground=FG,
                    arrowcolor=FG, padding=8)
        s.map("TCombobox", fieldbackground=[("readonly", PANEL2)], foreground=[("readonly", FG)])
        s.configure("Horizontal.TProgressbar", troughcolor=PANEL2, background=ACCENT,
                    bordercolor=PANEL2, lightcolor=ACCENT, darkcolor=ACCENT)

    def _splash(self):
        self.splash = tk.Frame(self.root, bg=BG)
        self.splash.pack(fill="both", expand=True)
        logo = ROOT / "zapret_logo.png"
        if logo.exists():
            try:
                self.logo_img = tk.PhotoImage(file=str(logo))
                tk.Label(self.splash, image=self.logo_img, bg=BG).pack(pady=(130, 12))
            except Exception:
                pass
        tk.Label(self.splash, text="ZAPRET", font=("Segoe UI", 27, "bold"), bg=BG, fg=FG).pack(pady=5)
        tk.Label(self.splash, text="CONTROL CENTER", font=("Segoe UI", 10, "bold"),
                 bg=BG, fg=MUTED).pack(pady=(0, 24))
        self.bar = ttk.Progressbar(self.splash, mode="indeterminate", length=280)
        self.bar.pack()
        tk.Label(self.splash, text="Загружаем списки и стратегии…", bg=BG, fg=MUTED).pack(pady=12)
        self.root.after(700, self._load)

    def _load(self):
        self.bar.stop()
        self.splash.destroy()
        LISTS_DIR.mkdir(exist_ok=True)
        self._load_lists()
        self._main()

    def _button(self, parent, text, cmd, color=ACCENT):
        return tk.Button(parent, text=text, command=cmd, bg=color, fg="white",
            activebackground=color, activeforeground="white", relief="flat", bd=0,
            padx=13, pady=9, font=("Segoe UI", 10, "bold"), cursor="hand2")

    def _card(self, parent):
        return tk.Frame(parent, bg=PANEL, padx=18, pady=16)

    def _main(self):
        shell = tk.Frame(self.root, bg=BG)
        shell.pack(fill="both", expand=True, padx=24, pady=22)
        head = tk.Frame(shell, bg=BG)
        head.pack(fill="x", pady=(0, 18))
        tk.Label(head, text="Zapret", font=("Segoe UI", 24, "bold"), bg=BG, fg=FG).pack(side="left")
        tk.Label(head, text="CONTROL CENTER  /  DOMAIN LISTS", font=("Segoe UI", 9, "bold"),
                 bg=BG, fg=MUTED).pack(side="left", padx=16, pady=(12,0))

        strategy_card = self._card(shell)
        strategy_card.pack(fill="x", pady=(0, 12))
        tk.Label(strategy_card, text="СТРАТЕГИЯ ОБХОДА", bg=PANEL, fg=MUTED,
                 font=("Segoe UI", 9, "bold")).pack(anchor="w")
        row = tk.Frame(strategy_card, bg=PANEL); row.pack(fill="x", pady=(9,0))
        self.strategy_box = ttk.Combobox(row, textvariable=self.strategy, state="readonly",
                                         values=self._strategies(), font=("Segoe UI", 10))
        self.strategy_box.pack(side="left", fill="x", expand=True, ipady=3)
        self._button(row, "▶ Запустить", self.start_strategy).pack(side="left", padx=(10,0))
        self._button(row, "■ Остановить", self.stop_strategy, RED).pack(side="left", padx=(8,0))

        lists_card = self._card(shell)
        lists_card.pack(fill="both", expand=True, pady=(0, 12))
        top = tk.Frame(lists_card, bg=PANEL); top.pack(fill="x")
        tk.Label(top, text="МОИ СПИСКИ ДОМЕНОВ", bg=PANEL, fg=FG,
                 font=("Segoe UI", 13, "bold")).pack(side="left")
        for label, fn, color in [
            ("＋ Новый лист", self.new_list, ACCENT),
            ("Импорт .zapret", self.import_list, "#5367a5"),
            ("Экспорт .zapret", self.export_list, "#5367a5")]:
            self._button(top, label, fn, color).pack(side="right", padx=(7,0))
        select_row = tk.Frame(lists_card, bg=PANEL); select_row.pack(fill="x", pady=(14,10))
        tk.Label(select_row, text="Активный лист", bg=PANEL, fg=MUTED).pack(side="left")
        self.list_box = ttk.Combobox(select_row, textvariable=self.active, state="readonly",
                                     font=("Segoe UI", 10), width=30)
        self.list_box.pack(side="left", padx=12)
        self.list_box.bind("<<ComboboxSelected>>", self.switch_list)
        self._button(select_row, "Переименовать", self.rename_list, PANEL2).pack(side="left")
        self._button(select_row, "Удалить", self.delete_list, RED).pack(side="left", padx=7)

        editor = tk.Frame(lists_card, bg=PANEL); editor.pack(fill="both", expand=True)
        tk.Label(editor, text="Домены — по одному на строку. Можно вводить example.com или поддомен.",
                 bg=PANEL, fg=MUTED, font=("Segoe UI", 9)).pack(anchor="w", pady=(0,7))
        self.domain_text = tk.Text(editor, bg=PANEL2, fg=FG, insertbackground=FG,
                                   selectbackground=ACCENT, relief="flat", bd=0,
                                   font=("Cascadia Code", 10), padx=12, pady=10, undo=True)
        self.domain_text.pack(fill="both", expand=True)
        self.domain_text.bind("<<Modified>>", self._edited)
        foot = tk.Frame(lists_card, bg=PANEL); foot.pack(fill="x", pady=(10,0))
        self.count_label = tk.Label(foot, text="0 доменов", bg=PANEL, fg=MUTED)
        self.count_label.pack(side="left")
        self._button(foot, "Сохранить лист", self.save_current, GREEN).pack(side="right")
        self._button(foot, "⟳ Обновить IP-список", self.update_ipset, PANEL2).pack(side="right", padx=8)

        status = tk.Frame(shell, bg=PANEL2, padx=12, pady=10); status.pack(fill="x")
        tk.Label(status, text="●", bg=PANEL2, fg=GREEN).pack(side="left")
        tk.Label(status, textvariable=self.status, bg=PANEL2, fg=FG).pack(side="left", padx=8)
        self._refresh_list_choices()
        if not self.lists:
            self.lists["Мой список"] = []
        if not self.active.get():
            self.active.set(next(iter(self.lists)))
        self._refresh_list_choices()
        self._display_active()

    def _strategies(self):
        files = [p.name for p in ROOT.glob("*.bat")
                 if p.name.lower().startswith(("strategy ", "general"))]
        import re
        return sorted(files, key=lambda x: (int(re.search(r'\d+', x).group()) if re.search(r'\d+', x) else 9999, x.lower()))

    def _load_lists(self):
        self.lists = {}
        for p in LISTS_DIR.glob("*.json"):
            try:
                obj = json.loads(p.read_text(encoding="utf-8"))
                name = obj.get("name", p.stem)
                domains = obj.get("domains", [])
                self.lists[name] = self._clean_domains(domains)
            except Exception:
                continue
        if not self.lists:
            self.lists["Мой список"] = []
        self.active.set(next(iter(self.lists)))

    def _clean_domains(self, items):
        result, seen = [], set()
        for raw in items:
            d = str(raw).strip().lower()
            if not d or d.startswith("#") or d.startswith("//"):
                continue
            d = d.removeprefix("http://").removeprefix("https://").split("/")[0].split(":")[0].strip(".")
            if d and " " not in d and "." in d and d not in seen:
                seen.add(d); result.append(d)
        return result

    def _refresh_list_choices(self):
        if hasattr(self, "list_box"):
            names = list(self.lists)
            self.list_box["values"] = names
            if self.active.get() not in names and names:
                self.active.set(names[0])

    def _display_active(self):
        if not hasattr(self, "domain_text"): return
        self.domain_text.delete("1.0", "end")
        self.domain_text.insert("1.0", "\n".join(self.lists.get(self.active.get(), [])))
        self.domain_text.edit_modified(False)
        self._count()

    def _edited(self, _event=None):
        if self.domain_text.edit_modified():
            self._count()
            self.domain_text.edit_modified(False)

    def _current_domains(self):
        return self._clean_domains(self.domain_text.get("1.0", "end").splitlines())

    def _count(self):
        if hasattr(self, "count_label"):
            n = len(self._current_domains())
            self.count_label.config(text=f"{n} доменов")

    def switch_list(self, _event=None):
        self.save_current(silent=True)
        self._display_active()

    def save_current(self, silent=False):
        name = self.active.get()
        if name:
            self.lists[name] = self._current_domains()
            self._persist(name)
            self.status.set(f"Сохранено: {name}")
            if not silent: messagebox.showinfo("Сохранено", f"Список «{name}» сохранён.")

    def _persist(self, name):
        LISTS_DIR.mkdir(exist_ok=True)
        safe = "".join(c for c in name if c.isalnum() or c in " -_").strip() or "list"
        path = LISTS_DIR / (safe + ".json")
        path.write_text(json.dumps({"format":"zapret-domain-list","version":1,
                                    "name":name,"domains":self.lists.get(name,[])},
                                   ensure_ascii=False, indent=2), encoding="utf-8")

    def new_list(self):
        name = self._ask_name("Создать лист", "Название нового листа:")
        if not name: return
        if name in self.lists:
            messagebox.showwarning("Уже существует", "Лист с таким названием уже есть."); return
        self.save_current(silent=True)
        self.lists[name] = []
        self.active.set(name); self._persist(name); self._refresh_list_choices(); self._display_active()

    def _ask_name(self, title, prompt, initial=""):
        win = tk.Toplevel(self.root); win.title(title); win.configure(bg=PANEL); win.resizable(False, False)
        win.transient(self.root); win.grab_set()
        tk.Label(win, text=prompt, bg=PANEL, fg=FG, padx=18, pady=12).pack(anchor="w")
        ent = tk.Entry(win, bg=PANEL2, fg=FG, insertbackground=FG, relief="flat", width=35)
        ent.pack(padx=18, pady=(0,12), ipady=7); ent.insert(0, initial); ent.focus_set()
        result = {"value":None}
        def ok():
            v=ent.get().strip()
            if v: result["value"]=v
            win.destroy()
        self._button(win, "Готово", ok).pack(pady=(0,14))
        win.bind("<Return>", lambda _e: ok()); self.root.wait_window(win)
        return result["value"]

    def rename_list(self):
        old = self.active.get()
        name = self._ask_name("Переименовать лист", "Новое название:", old)
        if not name or name == old: return
        if name in self.lists:
            messagebox.showwarning("Уже существует", "Такой лист уже есть."); return
        self.save_current(silent=True)
        self.lists[name] = self.lists.pop(old)
        self.active.set(name); self._refresh_list_choices(); self._persist(name)
        self._display_active(); self.status.set(f"Лист переименован: {name}")

    def delete_list(self):
        name = self.active.get()
        if len(self.lists) <= 1:
            messagebox.showwarning("Нельзя удалить", "Должен остаться хотя бы один лист."); return
        if not messagebox.askyesno("Удалить лист", f"Удалить «{name}»?"): return
        self.lists.pop(name, None)
        self.active.set(next(iter(self.lists)))
        self._refresh_list_choices(); self._display_active(); self.status.set(f"Удалён: {name}")

    def import_list(self):
        path = filedialog.askopenfilename(title="Импорт списка", filetypes=[
            ("Zapret lists", "*.zapret"), ("Text files", "*.txt"), ("JSON files", "*.json"), ("All files", "*.*")])
        if not path: return
        try:
            p=Path(path)
            if p.suffix.lower()==".zapret":
                with zipfile.ZipFile(p) as z:
                    meta=json.loads(z.read("list.json").decode("utf-8"))
                name=str(meta.get("name", p.stem))
                domains=self._clean_domains(meta.get("domains", []))
            elif p.suffix.lower()==".json":
                meta=json.loads(p.read_text(encoding="utf-8-sig"))
                name=str(meta.get("name",p.stem)); domains=self._clean_domains(meta.get("domains",[]))
            else:
                name=p.stem
                domains=self._clean_domains(p.read_text(encoding="utf-8-sig").splitlines())
            if name in self.lists:
                name=self._ask_name("Импорт списка", "Такое имя уже занято. Название для импорта:", name+" (импорт)")
                if not name: return
            self.lists[name]=domains; self.active.set(name); self._persist(name)
            self._refresh_list_choices(); self._display_active()
            self.status.set(f"Импортировано: {name}")
            messagebox.showinfo("Импорт завершён", f"Лист «{name}»: {len(domains)} доменов.")
        except Exception as e:
            messagebox.showerror("Не удалось импортировать", f"Файл не распознан как список Zapret.\n{e}")

    def export_list(self):
        self.save_current(silent=True)
        name=self.active.get()
        path=filedialog.asksaveasfilename(title="Экспорт листа", defaultextension=".zapret",
            initialfile="".join(c for c in name if c.isalnum() or c in " -_")+".zapret",
            filetypes=[("Zapret domain list","*.zapret")])
        if not path: return
        try:
            payload=json.dumps({"format":"zapret-domain-list","version":1,"name":name,
                                "domains":self.lists.get(name,[])},ensure_ascii=False,indent=2).encode("utf-8")
            with zipfile.ZipFile(path,"w",zipfile.ZIP_DEFLATED) as z:
                z.writestr("list.json",payload)
                z.writestr("domains.txt","\n".join(self.lists.get(name,[]))+"\n")
            self.status.set(f"Экспортировано: {Path(path).name}")
            messagebox.showinfo("Экспорт готов", "Файл .zapret создан. Его можно импортировать в другом экземпляре GUI.")
        except Exception as e: messagebox.showerror("Ошибка экспорта",str(e))

    def start_strategy(self):
        name=self.strategy.get()
        if not name:
            messagebox.showwarning("Стратегия", "В архиве не найдено BAT-стратегий."); return
        if not messagebox.askyesno("Запуск от администратора",
            f"Запустить «{name}» с правами администратора?\n\nВыбранный лист «{self.active.get()}» хранится в GUI. Применение доменов зависит от поддержки со стороны стратегии."):
            return
        try:
            path=str(ROOT/name).replace("'","''")
            ps="Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', '\""+path+"\"' -Verb RunAs"
            subprocess.Popen(["powershell","-NoProfile","-ExecutionPolicy","Bypass","-Command",ps],
                cwd=str(ROOT),creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
            self.status.set("Запрос запуска отправлен — подтвердите UAC")
        except Exception as e: messagebox.showerror("Ошибка запуска",str(e))

    def stop_strategy(self):
        if not messagebox.askyesno("Остановить", "Завершить процессы winws.exe? Это остановит обход в других экземплярах тоже."): return
        ps="Start-Process -FilePath 'taskkill.exe' -ArgumentList '/F','/IM','winws.exe' -Verb RunAs -Wait"
        try:
            subprocess.Popen(["powershell","-NoProfile","-Command",ps],cwd=str(ROOT),
                creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
            self.status.set("Запрос остановки отправлен — подтвердите UAC")
        except Exception as e: messagebox.showerror("Ошибка",str(e))

    def update_ipset(self):
        if not messagebox.askyesno("Обновить IP-список", "Скачать ipset-all.txt из репозитория Flowseal?"): return
        self.status.set("Загрузка IP-списка…")
        threading.Thread(target=self._download_ipset,daemon=True).start()

    def _download_ipset(self):
        target=ROOT/"lists"/"ipset-all.txt"; tmp=target.with_suffix(".txt.download")
        try:
            target.parent.mkdir(exist_ok=True)
            req=urllib.request.Request(IPSET_URL,headers={"User-Agent":"Zapret-GUI/2.0"})
            with urllib.request.urlopen(req,timeout=30) as r: data=r.read()
            decoded=data.decode("utf-8-sig")
            if len(data)<20 or not any(x.strip() and not x.lstrip().startswith("#") for x in decoded.splitlines()):
                raise RuntimeError("Сервер вернул пустой или некорректный список.")
            tmp.write_bytes(data)
            if target.exists(): shutil.copy2(target,target.with_suffix(".txt.backup"))
            os.replace(tmp,target)
            self.root.after(0,lambda: self.status.set("IP-список обновлён"))
            self.root.after(0,lambda: messagebox.showinfo("Готово","IP-список обновлён; предыдущая версия сохранена."))
        except Exception as e:
            try: tmp.unlink(missing_ok=True)
            except Exception: pass
            self.root.after(0,lambda: self.status.set("Ошибка обновления IP-списка"))
            self.root.after(0,lambda err=str(e): messagebox.showerror("Ошибка обновления",err))

def main():
    if os.name != "nt":
        print("Эта оболочка рассчитана на Windows."); return
    root=tk.Tk(); App(root); root.mainloop()

if __name__=="__main__": main()
