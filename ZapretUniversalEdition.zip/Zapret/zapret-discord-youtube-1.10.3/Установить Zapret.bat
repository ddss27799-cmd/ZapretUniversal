@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo ==========================================
echo       Zapret Control Center - Setup
echo ==========================================
where py.exe >nul 2>&1
if errorlevel 1 (
  where python.exe >nul 2>&1
  if errorlevel 1 (
    echo Python 3 is not installed. Install Python 3 from python.org and retry.
    pause
    exit /b 1
  )
)
set "TARGET=%LOCALAPPDATA%\ZapretControlCenter"
if not exist "%TARGET%" mkdir "%TARGET%"
echo Copying application to "%TARGET%"...
xcopy "%~dp0*" "%TARGET%\" /E /I /Y /Q >nul
if errorlevel 1 (
  echo Copy failed.
  pause
  exit /b 1
)
set "PS1=%TEMP%\zapret_shortcut_%RANDOM%.ps1"
(
echo $WshShell = New-Object -ComObject WScript.Shell
echo $Desktop = [Environment]::GetFolderPath('Desktop')
echo $Shortcut = $WshShell.CreateShortcut((Join-Path $Desktop 'Zapret Control Center.lnk'))
echo $Shortcut.TargetPath = Join-Path '%TARGET%' 'Запустить GUI.bat'
echo $Shortcut.WorkingDirectory = '%TARGET%'
echo $Shortcut.Description = 'Zapret Control Center'
echo $Icon = Join-Path '%TARGET%' 'zapret_logo.ico'
echo if (Test-Path $Icon) { $Shortcut.IconLocation = "$Icon,0" }
echo $Shortcut.Save()
) > "%PS1%"
powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%"
del "%PS1%" >nul 2>&1
echo.
echo Installation complete. Desktop shortcut created.
echo App folder: %TARGET%
pause
