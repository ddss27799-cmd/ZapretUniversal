@echo off
chcp 65001 >nul
cd /d "%~dp0"
where pyw.exe >nul 2>&1
if %errorlevel%==0 (start "" pyw.exe "%~dp0zapret_gui.py") else (start "" pythonw.exe "%~dp0zapret_gui.py")
